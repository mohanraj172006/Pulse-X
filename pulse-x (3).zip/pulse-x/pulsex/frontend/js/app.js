const pages = {
  dashboard: document.getElementById("page-dashboard"),
  monitor: document.getElementById("page-monitor"),
  batch: document.getElementById("page-batch"),
  analytics: document.getElementById("page-analytics"),
};

function navigate(page) {
  Object.entries(pages).forEach(([k, el]) => {
    if (el) el.classList.toggle("hidden", k !== page);
  });
  document.querySelectorAll(".nav-item").forEach(n => {
    n.classList.toggle("active", n.dataset.page === page);
  });
  const titles = {
    dashboard: "Dashboard — Verify Startup",
    monitor: "IoT Monitor — Live Sensors",
    batch: "Batch Analysis",
    analytics: "Analytics & History",
  };
  const t = document.getElementById("topbar-title");
  if (t) t.textContent = titles[page] || "Pulse X";
  if (page === "monitor") window.PulseMonitor && window.PulseMonitor.initMonitorPage();
  if (page === "batch") window.PulseBatch && window.PulseBatch.initBatch();
  if (page === "analytics") loadAnalytics();
}

function showToast(severity, title, message) {
  const container = document.getElementById("toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = `toast ${severity}`;
  toast.innerHTML = `
    <span class="toast-icon"></span>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-msg">${message}</div>
    </div>
    <span class="toast-close" onclick="this.parentElement.remove()">✕</span>
  `;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("exit");
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

async function loadAnalytics() {
  const el = document.getElementById("analytics-content");
  if (!el) return;
  try {
    const data = await window.PulseAPI.apiGet("/health");
    el.innerHTML = `
      <div class="metrics-grid">
        <div class="metric-card cyan card-appear">
          <div class="metric-icon">🔍</div>
          <div class="metric-value" style="color:var(--cyan)">—</div>
          <div class="metric-label">Total Analyses</div>
        </div>
        <div class="metric-card purple card-appear">
          <div class="metric-icon">🤖</div>
          <div class="metric-value" style="color:var(--purple)">3</div>
          <div class="metric-label">Active Agents</div>
        </div>
        <div class="metric-card green card-appear">
          <div class="metric-icon">📡</div>
          <div class="metric-value" style="color:var(--green)">5</div>
          <div class="metric-label">IoT Sensors</div>
        </div>
        <div class="metric-card red card-appear">
          <div class="metric-icon">⚠️</div>
          <div class="metric-value" style="color:var(--red)">0</div>
          <div class="metric-label">Active Alerts</div>
        </div>
      </div>
      <div class="chart-wrap">
        <div class="chart-title">Agent Performance Overview</div>
        <canvas id="analytics-chart" style="width:100%;height:200px"></canvas>
      </div>
    `;
    setTimeout(() => {
      if (window.PulseCharts) {
        window.PulseCharts.drawScoreChart("analytics-chart", [
          { label: "Verification", value: 78, color: "#00d4ff" },
          { label: "Insight", value: 82, color: "#7b2ff7" },
          { label: "Security", value: 71, color: "#ff2d78" },
          { label: "Avg Trust", value: 77, color: "#00ff88" },
        ]);
      }
    }, 100);
  } catch (e) {
    el.innerHTML = `<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">No data yet</div><div class="empty-sub">Run some analyses to see statistics here.</div></div>`;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".nav-item").forEach(n => {
    n.addEventListener("click", () => navigate(n.dataset.page));
  });
  navigate("dashboard");
  window.PulseDashboard && window.PulseDashboard.initDashboard();
});

window.PulseToast = { show: showToast };
window.PulseApp = { navigate };

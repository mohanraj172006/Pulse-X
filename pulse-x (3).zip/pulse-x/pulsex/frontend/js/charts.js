function drawScoreChart(canvasId, data) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);
  const w = rect.width, h = rect.height;
  ctx.clearRect(0, 0, w, h);
  const labels = data.map(d => d.label);
  const values = data.map(d => d.value);
  const colors = data.map(d => d.color || "#00d4ff");
  const barW = Math.min(60, (w - 80) / labels.length - 16);
  const maxVal = 100;
  const chartH = h - 50;
  const startX = 50;
  ctx.strokeStyle = "#1e1e3f";
  ctx.lineWidth = 1;
  [0, 25, 50, 75, 100].forEach(v => {
    const y = chartH - (v / maxVal) * chartH + 10;
    ctx.beginPath();
    ctx.moveTo(startX, y);
    ctx.lineTo(w - 10, y);
    ctx.stroke();
    ctx.fillStyle = "#4a4d6a";
    ctx.font = "10px Inter";
    ctx.textAlign = "right";
    ctx.fillText(v, startX - 6, y + 4);
  });
  labels.forEach((label, i) => {
    const x = startX + i * ((w - startX - 10) / labels.length) + (w - startX - 10) / labels.length / 2 - barW / 2;
    const val = values[i];
    const barH = (val / maxVal) * chartH;
    const y = chartH - barH + 10;
    const grad = ctx.createLinearGradient(0, y, 0, chartH + 10);
    grad.addColorStop(0, colors[i]);
    grad.addColorStop(1, colors[i] + "40");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, 6);
    ctx.fill();
    ctx.fillStyle = colors[i];
    ctx.font = "bold 12px Inter";
    ctx.textAlign = "center";
    ctx.fillText(Math.round(val), x + barW / 2, y - 6);
    ctx.fillStyle = "#8b8fa8";
    ctx.font = "11px Inter";
    ctx.fillText(label, x + barW / 2, h - 6);
  });
}

window.PulseCharts = { drawScoreChart };

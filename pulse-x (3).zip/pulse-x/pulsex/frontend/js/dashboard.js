// let currentResult = null;
// let currentWS = null;

// function initDashboard() {
//   const form = document.getElementById("verify-form");
//   if (form) {
//     form.addEventListener("submit", async (e) => {
//       e.preventDefault();
//       const url = document.getElementById("startup-url").value.trim();
//       const name = document.getElementById("startup-name").value.trim();
//       if (!url) return;
//       await runVerification(url, name);
//     });
//   }
//   const feedbackSlider = document.getElementById("feedback-slider");
//   if (feedbackSlider) {
//     feedbackSlider.addEventListener("input", () => {
//       document.getElementById("feedback-val").textContent = feedbackSlider.value;
//     });
//   }
//   loadRecentAnalyses();
// }

// async function runVerification(url, name) {
//   showAgentsSection();
//   setAgentProgress("verification", 0, "Checking LinkedIn & MCA...");
//   setAgentProgress("insight", 0, "Waiting...");
//   setAgentProgress("security", 0, "Waiting...");
//   document.getElementById("results-section").classList.add("hidden");
//   animateAgent("verification", 0, 60, 1800);
//   try {
//     const result = await window.PulseAPI.apiPost("/startups/verify", {
//       url, name: name || null, enterprise_id: "default"
//     });
//     setAgentProgress("verification", 100, "Complete");
//     setAgentProgress("insight", 100, "Complete");
//     setAgentProgress("security", 100, "Complete");
//     setTimeout(() => {
//       currentResult = result;
//       if (result.id) {
//         localStorage.setItem("lastStartupId", result.id);
//         if (window.PulseMonitor) window.PulseMonitor.subscribeStartup(result.id);
//       }
//       renderResults(result);
//       document.getElementById("agents-section").classList.remove("visible");
//     }, 600);
//   } catch (err) {
//     setAgentProgress("verification", 0, "Error: " + err.message);
//     window.PulseToast && window.PulseToast.show("CRITICAL", "Verification Failed", err.message);
//   }
// }

// function animateAgent(id, from, to, duration) {
//   const start = Date.now();
//   const timer = setInterval(() => {
//     const elapsed = Date.now() - start;
//     const pct = Math.min((elapsed / duration) * (to - from) + from, to);
//     setAgentProgress(id, pct, id === "verification" ? "Analyzing data..." : "Processing...");
//     if (pct >= to) clearInterval(timer);
//   }, 50);
// }

// function showAgentsSection() {
//   const sec = document.getElementById("agents-section");
//   sec.classList.add("visible");
//   sec.classList.remove("hidden");
//   animateAgent("verification", 0, 90, 3000);
//   setTimeout(() => animateAgent("insight", 0, 85, 3500), 500);
//   setTimeout(() => animateAgent("security", 0, 80, 4000), 1000);
// }

// function setAgentProgress(id, pct, status) {
//   const bar = document.getElementById(`agent-bar-${id}`);
//   const val = document.getElementById(`agent-val-${id}`);
//   const stat = document.getElementById(`agent-status-${id}`);
//   if (bar) bar.style.width = pct + "%";
//   if (val) val.textContent = Math.round(pct) + "%";
//   if (stat) stat.textContent = status;
// }

// function renderResults(data) {
//   const sec = document.getElementById("results-section");
//   sec.classList.remove("hidden");
//   sec.classList.add("animate-fade");
//   renderScoreGauge(data.trust_score, data.trust_color);
//   document.getElementById("score-level-badge").textContent = data.trust_level;
//   document.getElementById("score-level-badge").className = "level-badge " + data.trust_color;
//   document.getElementById("score-recommendation").textContent = data.recommendation;
//   document.getElementById("result-name").textContent = data.name;
//   renderVerification(data.verification);
//   renderInsight(data.insight);
//   renderSecurity(data.security);
//   renderSources(data.sources);
//   if (window.PulseCharts) {
//     setTimeout(() => {
//       window.PulseCharts.drawScoreChart("score-chart", [
//         { label: "Verification", value: data.verification.score, color: "#00d4ff" },
//         { label: "Insight", value: data.insight.score, color: "#7b2ff7" },
//         { label: "Security", value: data.security.score, color: "#ff2d78" },
//         { label: "Overall", value: data.trust_score, color: "#00ff88" },
//       ]);
//     }, 200);
//   }
//   document.getElementById("feedback-startup-id").value = data.id || "";
//   document.getElementById("feedback-predicted").value = data.trust_score;
// }

// function renderScoreGauge(score, color) {
//   const colorMap = { green: "#00ff88", yellow: "#ffd600", red: "#ff3b5c" };
//   const strokeColor = colorMap[color] || "#00d4ff";
//   const r = 64, circ = 2 * Math.PI * r;
//   const offset = circ - (score / 100) * circ;
//   const fill = document.getElementById("gauge-fill");
//   const num = document.getElementById("gauge-number");
//   if (fill) {
//     fill.style.stroke = strokeColor;
//     fill.style.strokeDasharray = circ;
//     fill.style.strokeDashoffset = circ;
//     setTimeout(() => { fill.style.strokeDashoffset = offset; }, 100);
//   }
//   if (num) {
//     num.style.color = strokeColor;
//     let current = 0;
//     const step = score / 60;
//     const timer = setInterval(() => {
//       current = Math.min(current + step, score);
//       num.textContent = Math.round(current);
//       if (current >= score) clearInterval(timer);
//     }, 16);
//   }
// }

// function renderVerification(v) {
//   const body = document.getElementById("ver-body");
//   if (!body) return;
//   body.innerHTML = `
//     <div class="detail-row"><span class="detail-key">LinkedIn Presence</span><span class="detail-val ${v.linkedin_presence ? 'good' : 'bad'}">${v.linkedin_presence ? '✓ Verified' : '✗ Not Found'}</span></div>
//     <div class="detail-row"><span class="detail-key">Employees (Claimed)</span><span class="detail-val">${v.employee_count_claimed || 'Not Found'}</span></div>
//     <div class="detail-row"><span class="detail-key">Employees (Verified)</span><span class="detail-val">${v.employee_count_verified || 'Not Found'}</span></div>
//     <div class="detail-row"><span class="detail-key">Founded (Claimed)</span><span class="detail-val">${v.founded_year_claimed || 'Not Found'}</span></div>
//     <div class="detail-row"><span class="detail-key">Founded (Verified)</span><span class="detail-val">${v.founded_year_verified || 'Not Found'}</span></div>
//     <div class="detail-row"><span class="detail-key">MCA Registered</span><span class="detail-val ${v.mca_registered ? 'good' : 'warn'}">${v.mca_registered ? '✓ ' + (v.mca_cin || 'Yes') : '✗ Not Found'}</span></div>
//     <div class="detail-row"><span class="detail-key">MCA Status</span><span class="detail-val">${v.mca_status || 'N/A'}</span></div>
//     <div class="detail-row"><span class="detail-key">News Mentions</span><span class="detail-val">${v.news_mentions}</span></div>
//     ${v.discrepancies.length ? `<div class="section-sep"></div><div style="font-size:12px;color:var(--text2);margin-bottom:8px;font-weight:600">DISCREPANCIES</div>${v.discrepancies.map(d => `<div class="flag-item"><span class="flag-dot"></span>${d}</div>`).join('')}` : ''}
//   `;
// }

// function renderInsight(ins) {
//   const body = document.getElementById("ins-body");
//   if (!body) return;
//   body.innerHTML = `
//     <div class="detail-row"><span class="detail-key">Category</span><span class="detail-val">${ins.innovation_category || 'General'}</span></div>
//     <div class="detail-row"><span class="detail-key">Industry</span><span class="detail-val">${ins.industry || 'Technology'}</span></div>
//     <div class="detail-row"><span class="detail-key">Maturity</span><span class="detail-val">${ins.maturity_level || 'Early'}</span></div>
//     <div class="detail-row"><span class="detail-key">Relevance Score</span><span class="detail-val">${ins.relevance_score}/100</span></div>
//     <div class="section-sep"></div>
//     <div style="font-size:12px;color:var(--text2);margin-bottom:8px;font-weight:600">TECH TAGS</div>
//     <div>${(ins.tech_tags || []).map(t => `<span class="tag">${t}</span>`).join('')}</div>
//     ${ins.description_summary ? `<div class="section-sep"></div><div style="font-size:13px;color:var(--text2);line-height:1.6">${ins.description_summary}</div>` : ''}
//   `;
// }

// function renderSecurity(sec) {
//   const body = document.getElementById("sec-body");
//   if (!body) return;
//   body.innerHTML = `
//     <div class="detail-row"><span class="detail-key">SSL Valid</span><span class="detail-val ${sec.ssl_valid ? 'good' : 'bad'}">${sec.ssl_valid ? '✓ Valid' : '✗ Invalid'}</span></div>
//     <div class="detail-row"><span class="detail-key">SSL Expiry</span><span class="detail-val ${(sec.ssl_expiry_days || 999) < 30 ? 'bad' : 'good'}">${sec.ssl_expiry_days != null ? sec.ssl_expiry_days + ' days' : 'N/A'}</span></div>
//     <div class="detail-row"><span class="detail-key">Domain Age</span><span class="detail-val ${(sec.domain_age_days || 999) < 180 ? 'warn' : 'good'}">${sec.domain_age_days != null ? sec.domain_age_days + ' days' : 'N/A'}</span></div>
//     <div class="detail-row"><span class="detail-key">Credential Leaks</span><span class="detail-val ${sec.credential_leaks > 0 ? 'bad' : 'good'}">${sec.credential_leaks > 0 ? '⚠ ' + sec.credential_leaks + ' breach(es)' : '✓ Clean'}</span></div>
//     <div class="detail-row"><span class="detail-key">DNS Anomaly</span><span class="detail-val ${sec.dns_anomaly ? 'bad' : 'good'}">${sec.dns_anomaly ? '✗ Detected' : '✓ Normal'}</span></div>
//     <div class="detail-row"><span class="detail-key">SPF</span><span class="detail-val ${sec.email_spf ? 'good' : 'warn'}">${sec.email_spf ? '✓' : '✗ Missing'}</span></div>
//     <div class="detail-row"><span class="detail-key">DKIM</span><span class="detail-val ${sec.email_dkim ? 'good' : 'warn'}">${sec.email_dkim ? '✓' : '✗ Missing'}</span></div>
//     <div class="detail-row"><span class="detail-key">DMARC</span><span class="detail-val ${sec.email_dmarc ? 'good' : 'warn'}">${sec.email_dmarc ? '✓' : '✗ Missing'}</span></div>
//     <div class="detail-row"><span class="detail-key">Open Ports</span><span class="detail-val">${sec.open_ports.length ? sec.open_ports.join(', ') : 'None detected'}</span></div>
//     <div class="detail-row"><span class="detail-key">Risk Level</span><span class="detail-val ${sec.risk_level === 'LOW' ? 'good' : sec.risk_level === 'MEDIUM' ? 'warn' : 'bad'}">${sec.risk_level}</span></div>
//     ${sec.flags.length ? `<div class="section-sep"></div><div style="font-size:12px;color:var(--text2);margin-bottom:8px;font-weight:600">SECURITY FLAGS</div>${sec.flags.map(f => `<div class="flag-item"><span class="flag-dot"></span>${f}</div>`).join('')}` : ''}
//   `;
// }

// function renderSources(sources) {
//   const body = document.getElementById("sources-body");
//   if (!body) return;
//   body.innerHTML = sources.length
//     ? sources.map(s => `<div class="source-item">${s}</div>`).join("")
//     : '<div style="color:var(--text2);font-size:13px">No sources recorded</div>';
// }

// async function submitFeedback() {
//   const id = document.getElementById("feedback-startup-id").value;
//   const predicted = parseFloat(document.getElementById("feedback-predicted").value);
//   const actual = parseFloat(document.getElementById("feedback-slider").value);
//   const reason = document.getElementById("feedback-reason").value;
//   if (!id) return;
//   try {
//     await window.PulseAPI.apiPost("/feedback/", {
//       startup_id: id, predicted_score: predicted,
//       actual_score: actual, reason, enterprise_id: "default"
//     });
//     window.PulseToast && window.PulseToast.show("LOW", "Feedback Submitted", "Model weights updated. Thank you!");
//   } catch (e) {
//     window.PulseToast && window.PulseToast.show("MEDIUM", "Error", e.message);
//   }
// }

// function toggleCard(id) {
//   const body = document.getElementById(id + "-body");
//   const icon = document.getElementById(id + "-icon");
//   if (body) body.classList.toggle("open");
//   if (icon) icon.classList.toggle("open");
// }

// async function loadRecentAnalyses() {
//   const el = document.getElementById("recent-count");
//   if (el) el.textContent = "0";
// }

// window.PulseDashboard = { initDashboard, runVerification, submitFeedback, toggleCard };


let currentResult = null;
let currentWS = null;

function initDashboard() {
  const form = document.getElementById("verify-form");
  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const url = document.getElementById("startup-url").value.trim();
      const name = document.getElementById("startup-name").value.trim();
      if (!url) return;
      await runVerification(url, name);
    });
  }
  const feedbackSlider = document.getElementById("feedback-slider");
  if (feedbackSlider) {
    feedbackSlider.addEventListener("input", () => {
      document.getElementById("feedback-val").textContent = feedbackSlider.value;
    });
  }
  loadRecentAnalyses();
}

async function runVerification(url, name) {
  showAgentsSection();
  setAgentProgress("verification", 0, "Checking LinkedIn & MCA...");
  setAgentProgress("insight", 0, "Waiting...");
  setAgentProgress("security", 0, "Waiting...");
  document.getElementById("results-section").classList.add("hidden");
  animateAgent("verification", 0, 60, 1800);
  try {
    const result = await window.PulseAPI.apiPost("/startups/verify", {
      url, name: name || null, enterprise_id: "default"
    });
    setAgentProgress("verification", 100, "Complete");
    setAgentProgress("insight", 100, "Complete");
    setAgentProgress("security", 100, "Complete");
    setTimeout(() => {
      currentResult = result;
      if (result.id) {
        localStorage.setItem("lastStartupId", result.id);
        if (window.PulseMonitor) window.PulseMonitor.subscribeStartup(result.id);
      }
      renderResults(result);
      document.getElementById("agents-section").classList.remove("visible");
    }, 600);
  } catch (err) {
    setAgentProgress("verification", 0, "Error: " + err.message);
    window.PulseToast && window.PulseToast.show("CRITICAL", "Verification Failed", err.message);
  }
}

function animateAgent(id, from, to, duration) {
  const start = Date.now();
  const timer = setInterval(() => {
    const elapsed = Date.now() - start;
    const pct = Math.min((elapsed / duration) * (to - from) + from, to);
    setAgentProgress(id, pct, id === "verification" ? "Analyzing data..." : "Processing...");
    if (pct >= to) clearInterval(timer);
  }, 50);
}

function showAgentsSection() {
  const sec = document.getElementById("agents-section");
  sec.classList.add("visible");
  sec.classList.remove("hidden");
  animateAgent("verification", 0, 90, 3000);
  setTimeout(() => animateAgent("insight", 0, 85, 3500), 500);
  setTimeout(() => animateAgent("security", 0, 80, 4000), 1000);
}

function setAgentProgress(id, pct, status) {
  const bar = document.getElementById(`agent-bar-${id}`);
  const val = document.getElementById(`agent-val-${id}`);
  const stat = document.getElementById(`agent-status-${id}`);
  if (bar) bar.style.width = pct + "%";
  if (val) val.textContent = Math.round(pct) + "%";
  if (stat) stat.textContent = status;
}

function renderResults(data) {
  const sec = document.getElementById("results-section");
  sec.classList.remove("hidden");
  sec.classList.add("animate-fade");
  renderScoreGauge(data.trust_score, data.trust_color);
  document.getElementById("score-level-badge").textContent = data.trust_level;
  document.getElementById("score-level-badge").className = "level-badge " + data.trust_color;
  document.getElementById("score-recommendation").textContent = data.recommendation;
  document.getElementById("result-name").textContent = data.name;
  renderVerification(data.verification);
  renderInsight(data.insight);
  renderSecurity(data.security);
  renderSources(data.sources);
  if (window.PulseCharts) {
    setTimeout(() => {
      window.PulseCharts.drawScoreChart("score-chart", [
        { label: "Verification", value: data.verification.score, color: "#00d4ff" },
        { label: "Insight", value: data.insight.score, color: "#7b2ff7" },
        { label: "Security", value: data.security.score, color: "#ff2d78" },
        { label: "Overall", value: data.trust_score, color: "#00ff88" },
      ]);
    }, 200);
  }
  document.getElementById("feedback-startup-id").value = data.id || "";
  document.getElementById("feedback-predicted").value = data.trust_score;
}

function renderScoreGauge(score, color) {
  const colorMap = { green: "#00ff88", yellow: "#ffd600", red: "#ff3b5c" };
  const strokeColor = colorMap[color] || "#00d4ff";
  const r = 64, circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  const fill = document.getElementById("gauge-fill");
  const num = document.getElementById("gauge-number");
  if (fill) {
    fill.style.stroke = strokeColor;
    fill.style.strokeDasharray = circ;
    fill.style.strokeDashoffset = circ;
    setTimeout(() => { fill.style.strokeDashoffset = offset; }, 100);
  }
  if (num) {
    num.style.color = strokeColor;
    let current = 0;
    const step = score / 60;
    const timer = setInterval(() => {
      current = Math.min(current + step, score);
      num.textContent = Math.round(current);
      if (current >= score) clearInterval(timer);
    }, 16);
  }
}

function renderVerification(v) {
  const body = document.getElementById("ver-body");
  if (!body) return;
  body.innerHTML = `
    <div class="detail-row"><span class="detail-key">LinkedIn Presence</span><span class="detail-val ${v.linkedin_presence ? 'good' : 'bad'}">${v.linkedin_presence ? '✓ Verified' : '✗ Not Found'}</span></div>
    <div class="detail-row"><span class="detail-key">Employees (Claimed)</span><span class="detail-val">${v.employee_count_claimed || 'Not Found'}</span></div>
    <div class="detail-row"><span class="detail-key">Employees (Verified)</span><span class="detail-val">${v.employee_count_verified || 'Not Found'}</span></div>
    <div class="detail-row"><span class="detail-key">Founded (Claimed)</span><span class="detail-val">${v.founded_year_claimed || 'Not Found'}</span></div>
    <div class="detail-row"><span class="detail-key">Founded (Verified)</span><span class="detail-val">${v.founded_year_verified || 'Not Found'}</span></div>
    <div class="detail-row"><span class="detail-key">MCA Registered</span><span class="detail-val ${v.mca_registered ? 'good' : 'warn'}">${v.mca_registered ? '✓ ' + (v.mca_cin || 'Yes') : '✗ Not Found'}</span></div>
    <div class="detail-row"><span class="detail-key">MCA Status</span><span class="detail-val">${v.mca_status || 'N/A'}</span></div>
    <div class="detail-row"><span class="detail-key">News Mentions</span><span class="detail-val">${v.news_mentions}</span></div>
    ${v.discrepancies.length ? `<div class="section-sep"></div><div style="font-size:12px;color:var(--text2);margin-bottom:8px;font-weight:600">DISCREPANCIES</div>${v.discrepancies.map(d => `<div class="flag-item"><span class="flag-dot"></span>${d}</div>`).join('')}` : ''}
  `;
}

function renderInsight(ins) {
  const body = document.getElementById("ins-body");
  if (!body) return;
  body.innerHTML = `
    <div class="detail-row"><span class="detail-key">Category</span><span class="detail-val">${ins.innovation_category || 'General'}</span></div>
    <div class="detail-row"><span class="detail-key">Industry</span><span class="detail-val">${ins.industry || 'Technology'}</span></div>
    <div class="detail-row"><span class="detail-key">Maturity</span><span class="detail-val">${ins.maturity_level || 'Early'}</span></div>
    <div class="detail-row"><span class="detail-key">Relevance Score</span><span class="detail-val">${ins.relevance_score}/100</span></div>
    <div class="section-sep"></div>
    <div style="font-size:12px;color:var(--text2);margin-bottom:8px;font-weight:600">TECH TAGS</div>
    <div>${(ins.tech_tags || []).map(t => `<span class="tag">${t}</span>`).join('')}</div>
    ${ins.description_summary ? `<div class="section-sep"></div><div style="font-size:13px;color:var(--text2);line-height:1.6">${ins.description_summary}</div>` : ''}
  `;
}

function renderSecurity(sec) {
  const body = document.getElementById("sec-body");
  if (!body) return;
  body.innerHTML = `
    <div class="detail-row"><span class="detail-key">SSL Valid</span><span class="detail-val ${sec.ssl_valid ? 'good' : 'bad'}">${sec.ssl_valid ? '✓ Valid' : '✗ Invalid'}</span></div>
    <div class="detail-row"><span class="detail-key">SSL Expiry</span><span class="detail-val ${(sec.ssl_expiry_days || 999) < 30 ? 'bad' : 'good'}">${sec.ssl_expiry_days != null ? sec.ssl_expiry_days + ' days' : 'N/A'}</span></div>
    <div class="detail-row"><span class="detail-key">Domain Age</span><span class="detail-val ${(sec.domain_age_days || 999) < 180 ? 'warn' : 'good'}">${sec.domain_age_days != null ? sec.domain_age_days + ' days' : 'N/A'}</span></div>
    <div class="detail-row"><span class="detail-key">Credential Leaks</span><span class="detail-val ${sec.credential_leaks > 0 ? 'bad' : 'good'}">${sec.credential_leaks > 0 ? '⚠ ' + sec.credential_leaks + ' breach(es)' : '✓ Clean'}</span></div>
    <div class="detail-row"><span class="detail-key">DNS Anomaly</span><span class="detail-val ${sec.dns_anomaly ? 'bad' : 'good'}">${sec.dns_anomaly ? '✗ Detected' : '✓ Normal'}</span></div>
    <div class="detail-row"><span class="detail-key">SPF</span><span class="detail-val ${sec.email_spf ? 'good' : 'warn'}">${sec.email_spf ? '✓' : '✗ Missing'}</span></div>
    <div class="detail-row"><span class="detail-key">DKIM</span><span class="detail-val ${sec.email_dkim ? 'good' : 'warn'}">${sec.email_dkim ? '✓' : '✗ Missing'}</span></div>
    <div class="detail-row"><span class="detail-key">DMARC</span><span class="detail-val ${sec.email_dmarc ? 'good' : 'warn'}">${sec.email_dmarc ? '✓' : '✗ Missing'}</span></div>
    <div class="detail-row"><span class="detail-key">Open Ports</span><span class="detail-val">${sec.open_ports.length ? sec.open_ports.join(', ') : 'None detected'}</span></div>
    <div class="detail-row"><span class="detail-key">Risk Level</span><span class="detail-val ${sec.risk_level === 'LOW' ? 'good' : sec.risk_level === 'MEDIUM' ? 'warn' : 'bad'}">${sec.risk_level}</span></div>
    ${sec.flags.length ? `<div class="section-sep"></div><div style="font-size:12px;color:var(--text2);margin-bottom:8px;font-weight:600">SECURITY FLAGS</div>${sec.flags.map(f => `<div class="flag-item"><span class="flag-dot"></span>${f}</div>`).join('')}` : ''}
  `;
}

function renderSources(sources) {
  const body = document.getElementById("sources-body");
  if (!body) return;
  body.innerHTML = sources.length
    ? sources.map(s => `<div class="source-item">${s}</div>`).join("")
    : '<div style="color:var(--text2);font-size:13px">No sources recorded</div>';
}

async function submitFeedback() {
  const id = document.getElementById("feedback-startup-id").value;
  const predicted = parseFloat(document.getElementById("feedback-predicted").value);
  const actual = parseFloat(document.getElementById("feedback-slider").value);
  const reason = document.getElementById("feedback-reason").value;
  if (!id) return;
  try {
    await window.PulseAPI.apiPost("/feedback/", {
      startup_id: id, predicted_score: predicted,
      actual_score: actual, reason, enterprise_id: "default"
    });
    window.PulseToast && window.PulseToast.show("LOW", "Feedback Submitted", "Model weights updated. Thank you!");
  } catch (e) {
    window.PulseToast && window.PulseToast.show("MEDIUM", "Error", e.message);
  }
}

function toggleCard(id) {
  const body = document.getElementById(id + "-body");
  const icon = document.getElementById(id + "-icon");
  if (body) body.classList.toggle("open");
  if (icon) icon.classList.toggle("open");
}

async function loadRecentAnalyses() {
  const el = document.getElementById("recent-count");
  if (el) el.textContent = "0";
}

function downloadReport(data) {
  if (!data) return;
  const now = new Date().toLocaleString();
  const v = data.verification || {};
  const ins = data.insight || {};
  const sec = data.security || {};
  const scoreColor = data.trust_color === "green" ? "#00c853" : data.trust_color === "yellow" ? "#ffd600" : "#ff1744";
  const html = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"/>
<title>Pulse X Report — ${data.name}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,sans-serif;background:#fff;color:#1a1a2e;padding:40px;font-size:13px}
.header{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #0a0a2e;padding-bottom:20px;margin-bottom:28px}
.logo{font-size:28px;font-weight:900;color:#0a0a2e}.logo span{color:#00d4ff}
.score-section{display:flex;gap:24px;margin-bottom:28px;align-items:center;background:#f8f9ff;border-radius:12px;padding:24px}
.score-circle{width:120px;height:120px;border-radius:50%;background:conic-gradient(${scoreColor} ${data.trust_score*3.6}deg,#e0e0e0 0deg);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.score-inner{width:90px;height:90px;border-radius:50%;background:#f8f9ff;display:flex;flex-direction:column;align-items:center;justify-content:center}
.score-num{font-size:32px;font-weight:900;color:${scoreColor}}
.score-lbl{font-size:9px;color:#666;letter-spacing:1px}
.badge{display:inline-block;padding:6px 16px;border-radius:20px;font-size:12px;font-weight:700;background:${scoreColor}22;color:${scoreColor};border:1px solid ${scoreColor}44;margin-bottom:8px}
.section{margin-bottom:20px;border:1px solid #e0e0e0;border-radius:10px;overflow:hidden}
.section-header{background:#0a0a2e;color:#fff;padding:12px 18px;font-size:13px;font-weight:700}
.row{display:flex;justify-content:space-between;padding:9px 18px;border-bottom:1px solid #f0f0f0;font-size:12px}
.row:last-child{border-bottom:none}
.row-key{color:#555}
.good{color:#00c853;font-weight:600}.bad{color:#ff1744;font-weight:600}.warn{color:#ff6d00;font-weight:600}
.tag{background:#e8eaf6;color:#3f51b5;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600;margin:2px;display:inline-block}
.flag{padding:8px 18px;border-bottom:1px solid #f0f0f0;font-size:12px;color:#c62828}.flag::before{content:"⚠ "}
.source{font-size:11px;color:#555;padding:4px 18px}.source::before{content:"📎 "}
.footer{margin-top:28px;padding-top:14px;border-top:2px solid #0a0a2e;display:flex;justify-content:space-between;font-size:11px;color:#888}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
</style></head><body>
<div class="header">
  <div class="logo">Pulse<span>X</span></div>
  <div style="text-align:right;font-size:12px;color:#666">
    <div style="font-weight:700;font-size:14px">Governance-Grade Startup Health Card</div>
    <div>Generated: ${now}</div>
    <div>Confidential — For Enterprise Use Only</div>
  </div>
</div>
<div class="score-section">
  <div class="score-circle">
    <div class="score-inner">
      <div class="score-num">${Math.round(data.trust_score)}</div>
      <div class="score-lbl">TRUST SCORE</div>
    </div>
  </div>
  <div>
    <h2 style="font-size:22px;font-weight:800;margin-bottom:6px">${data.name}</h2>
    <div style="color:#666;font-size:12px;margin-bottom:10px">${data.url}</div>
    <div class="badge">${data.trust_level}</div>
    <div style="font-size:13px;color:#444;line-height:1.5;margin-top:6px">${data.recommendation}</div>
  </div>
</div>
<div class="grid2">
<div class="section">
  <div class="section-header">🔎 Verification Agent</div>
  <div class="row"><span class="row-key">LinkedIn Presence</span><span class="${v.linkedin_presence?'good':'bad'}">${v.linkedin_presence?'✓ Verified':'✗ Not Found'}</span></div>
  <div class="row"><span class="row-key">Employees (Claimed)</span><span>${v.employee_count_claimed||'Not Found'}</span></div>
  <div class="row"><span class="row-key">Employees (Verified)</span><span>${v.employee_count_verified||'Not Found'}</span></div>
  <div class="row"><span class="row-key">Founded (Claimed)</span><span>${v.founded_year_claimed||'Not Found'}</span></div>
  <div class="row"><span class="row-key">Founded (Verified)</span><span>${v.founded_year_verified||'Not Found'}</span></div>
  <div class="row"><span class="row-key">MCA Registered</span><span class="${v.mca_registered?'good':'warn'}">${v.mca_registered?'✓ '+(v.mca_cin||'Yes'):'✗ Not Found'}</span></div>
  <div class="row"><span class="row-key">MCA Status</span><span>${v.mca_status||'N/A'}</span></div>
  <div class="row"><span class="row-key">News Mentions</span><span>${v.news_mentions}</span></div>
  <div class="row"><span class="row-key">Score</span><span style="color:#00d4ff;font-weight:700">${v.score}/100</span></div>
  ${(v.discrepancies||[]).map(d=>`<div class="flag">${d}</div>`).join('')}
</div>
<div class="section">
  <div class="section-header">🧠 Innovation Insight</div>
  <div class="row"><span class="row-key">Category</span><span>${ins.innovation_category||'General'}</span></div>
  <div class="row"><span class="row-key">Industry</span><span>${ins.industry||'Technology'}</span></div>
  <div class="row"><span class="row-key">Maturity Level</span><span>${ins.maturity_level||'Early'}</span></div>
  <div class="row"><span class="row-key">Relevance Score</span><span>${ins.relevance_score}/100</span></div>
  <div class="row"><span class="row-key">Score</span><span style="color:#7b2ff7;font-weight:700">${ins.score}/100</span></div>
  <div style="padding:10px 18px">${(ins.tech_tags||[]).map(t=>`<span class="tag">${t}</span>`).join('')||'—'}</div>
</div>
</div>
<div class="section">
  <div class="section-header">🛡️ Security Hygiene</div>
  <div class="grid2">
    <div>
      <div class="row"><span class="row-key">SSL Valid</span><span class="${sec.ssl_valid?'good':'bad'}">${sec.ssl_valid?'✓ Valid':'✗ Invalid'}</span></div>
      <div class="row"><span class="row-key">SSL Expiry</span><span class="${(sec.ssl_expiry_days||999)<30?'bad':'good'}">${sec.ssl_expiry_days!=null?sec.ssl_expiry_days+' days':'N/A'}</span></div>
      <div class="row"><span class="row-key">Domain Age</span><span class="${(sec.domain_age_days||999)<180?'warn':'good'}">${sec.domain_age_days!=null?sec.domain_age_days+' days':'N/A'}</span></div>
      <div class="row"><span class="row-key">Credential Leaks</span><span class="${sec.credential_leaks>0?'bad':'good'}">${sec.credential_leaks>0?'⚠ '+sec.credential_leaks+' breach(es)':'✓ Clean'}</span></div>
      <div class="row"><span class="row-key">DNS Anomaly</span><span class="${sec.dns_anomaly?'bad':'good'}">${sec.dns_anomaly?'✗ Detected':'✓ Normal'}</span></div>
    </div>
    <div>
      <div class="row"><span class="row-key">SPF</span><span class="${sec.email_spf?'good':'warn'}">${sec.email_spf?'✓ Present':'✗ Missing'}</span></div>
      <div class="row"><span class="row-key">DKIM</span><span class="${sec.email_dkim?'good':'warn'}">${sec.email_dkim?'✓ Present':'✗ Missing'}</span></div>
      <div class="row"><span class="row-key">DMARC</span><span class="${sec.email_dmarc?'good':'warn'}">${sec.email_dmarc?'✓ Present':'✗ Missing'}</span></div>
      <div class="row"><span class="row-key">Open Ports</span><span>${sec.open_ports&&sec.open_ports.length?sec.open_ports.join(', '):'None'}</span></div>
      <div class="row"><span class="row-key">Risk Level</span><span class="${sec.risk_level==='LOW'?'good':sec.risk_level==='MEDIUM'?'warn':'bad'}">${sec.risk_level}</span></div>
    </div>
  </div>
  ${(sec.flags||[]).map(f=>`<div class="flag">${f}</div>`).join('')}
</div>
${data.sources&&data.sources.length?`<div class="section"><div class="section-header">📎 Data Sources</div>${data.sources.map(s=>`<div class="source">${s}</div>`).join('')}</div>`:''}
<div class="footer">
  <div>Pulse X — Enterprise Startup Trust Intelligence</div>
  <div>Score: ${Math.round(data.trust_score)}/100 | ${data.trust_level} | ${now}</div>
</div>
</body></html>`;
  const blob = new Blob([html],{type:"text/html"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `PulseX-${data.name.replace(/\s+/g,'-')}-Report.html`;
  a.click();
  window.PulseToast && window.PulseToast.show("LOW","Report Downloaded",`Health card for ${data.name} saved.`);
}

window.PulseDashboard = { initDashboard, runVerification, submitFeedback, toggleCard };
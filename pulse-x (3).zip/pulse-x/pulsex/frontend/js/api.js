const API_BASE = "http://localhost:8000/api";
const WS_BASE = "ws://localhost:8000/api";

async function apiPost(path, body) {
  const r = await fetch(API_BASE + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    const err = await r.json().catch(() => ({ detail: "Request failed" }));
    throw new Error(err.detail || "Request failed");
  }
  return r.json();
}

async function apiGet(path) {
  const r = await fetch(API_BASE + path);
  if (!r.ok) throw new Error("Request failed");
  return r.json();
}

function connectWS(startupId, onMessage) {
  const ws = new WebSocket(`${WS_BASE}/monitor/${startupId}`);
  ws.onmessage = (e) => { try { onMessage(JSON.parse(e.data)); } catch {} };
  ws.onerror = () => console.warn("WS error");
  return ws;
}

window.PulseAPI = { apiPost, apiGet, connectWS };

let activeAlerts = [];
let wsConnections = {};
let sensorStatus = {
  ssl: { name: "SSL Certificate", interval: "Every 6h", status: "active", icon: "🔒" },
  domain: { name: "Domain Registration", interval: "Every 24h", status: "active", icon: "🌐" },
  credential: { name: "Credential Leak", interval: "Every 7d", status: "active", icon: "🔑" },
  dns: { name: "DNS Records", interval: "Every 4h", status: "active", icon: "📡" },
  email: { name: "Email Security", interval: "Every 7d", status: "active", icon: "📧" },
};

function renderSensors() {
  const grid = document.getElementById("sensors-grid");
  if (!grid) return;
  grid.innerHTML = Object.entries(sensorStatus).map(([key, s]) => `
    <div class="sensor-card card-appear ${s.status === 'alert' ? 'alert' : ''}" id="sensor-${key}">
      <div class="sensor-header">
        <span style="font-size:22px">${s.icon}</span>
        <div style="flex:1">
          <div class="sensor-name">${s.name}</div>
          <div class="sensor-interval">${s.interval}</div>
        </div>
        <div class="sensor-dot ${s.status}"></div>
      </div>
      <div class="sensor-status">${s.message || "Monitoring active. No issues detected."}</div>
      <div class="sensor-last-check">Last check: ${s.lastCheck || "—"}</div>
      <div class="sensor-next-check">Next check: ${s.nextCheck || "Pending..."}</div>
    </div>
  `).join("");
}

function renderAlertsFeed() {
  const feed = document.getElementById("alerts-feed-body");
  if (!feed) return;
  if (!activeAlerts.length) {
    feed.innerHTML = `<div class="no-alerts">✅ No active alerts. All systems nominal.</div>`;
    return;
  }
  feed.innerHTML = activeAlerts.slice(0, 20).map(a => `
    <div class="alert-item">
      <div class="alert-severity ${a.severity || 'LOW'}"></div>
      <div class="alert-content">
        <div class="alert-msg">${a.message}</div>
        <div class="alert-meta">${a.domain || ''} • ${a.type || ''}</div>
      </div>
      <div class="alert-time">${formatTime(a.timestamp)}</div>
    </div>
  `).join("");
  document.getElementById("alert-count").textContent = activeAlerts.length;
}

function handleWSAlert(data) {
  activeAlerts.unshift(data);
  const typeMap = {
    SSL_EXPIRING: "ssl", SSL_INVALID: "ssl",
    DOMAIN_EXPIRING: "domain", DOMAIN_CHANGED: "domain",
    CREDENTIAL_LEAK: "credential",
    DNS_ANOMALY: "dns",
    EMAIL_SECURITY: "email",
  };
  const sensorKey = typeMap[data.type];
  if (sensorKey && sensorStatus[sensorKey]) {
    sensorStatus[sensorKey].status = "alert";
    sensorStatus[sensorKey].message = data.message;
    sensorStatus[sensorKey].lastCheck = formatTime(data.timestamp);
  }
  window.PulseToast && window.PulseToast.show(data.severity || "HIGH", data.type, data.message);
  renderSensors();
  renderAlertsFeed();
}

function subscribeStartup(startupId) {
  if (wsConnections[startupId]) return;
  const ws = window.PulseAPI.connectWS(startupId, handleWSAlert);
  wsConnections[startupId] = ws;
}

function formatTime(ts) {
  if (!ts) return "—";
  const d = new Date(ts);
  const now = new Date();
  const diff = Math.floor((now - d) / 1000);
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  return d.toLocaleTimeString();
}

function initMonitorPage() {
  renderSensors();
  renderAlertsFeed();
  const startupId = localStorage.getItem("lastStartupId");
  if (startupId) subscribeStartup(startupId);
}

window.PulseMonitor = { initMonitorPage, subscribeStartup, handleWSAlert, sensorStatus };

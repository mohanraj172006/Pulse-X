let batchResults = [];

function initBatch() {
  const dropzone = document.getElementById("batch-dropzone");
  const fileInput = document.getElementById("batch-file");
  if (dropzone) {
    dropzone.addEventListener("dragover", e => { e.preventDefault(); dropzone.classList.add("dragover"); });
    dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
    dropzone.addEventListener("drop", e => {
      e.preventDefault();
      dropzone.classList.remove("dragover");
      const file = e.dataTransfer.files[0];
      if (file) processFile(file);
    });
    dropzone.addEventListener("click", () => fileInput && fileInput.click());
  }
  if (fileInput) {
    fileInput.addEventListener("change", e => {
      if (e.target.files[0]) processFile(e.target.files[0]);
    });
  }
}

function processFile(file) {
  const reader = new FileReader();
  reader.onload = e => {
    const lines = e.target.result.split("\n").filter(l => l.trim());
    const startups = lines.slice(1).map(line => {
      const [url, name] = line.split(",").map(s => s.trim());
      return { url, name: name || null };
    }).filter(s => s.url);
    if (startups.length) runBatch(startups);
  };
  reader.readAsText(file);
}

async function runBatchManual() {
  const textarea = document.getElementById("batch-urls");
  if (!textarea) return;
  const lines = textarea.value.split("\n").filter(l => l.trim());
  const startups = lines.map(l => {
    const [url, name] = l.split(",").map(s => s.trim());
    return { url, name: name || null };
  }).filter(s => s.url);
  if (startups.length) await runBatch(startups);
}

async function runBatch(startups) {
  const btn = document.getElementById("batch-run-btn");
  if (btn) { btn.disabled = true; btn.textContent = "Analyzing..."; }
  document.getElementById("batch-status").textContent = `Processing ${startups.length} startup(s)...`;
  try {
    const data = await window.PulseAPI.apiPost("/batch/verify", { startups, enterprise_id: "default" });
    batchResults = data.results || [];
    renderBatchResults(batchResults);
  } catch (e) {
    window.PulseToast && window.PulseToast.show("CRITICAL", "Batch Error", e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Analyze All"; }
    document.getElementById("batch-status").textContent = "";
  }
}

function renderBatchResults(results) {
  const wrap = document.getElementById("batch-results-wrap");
  const tbody = document.getElementById("batch-tbody");
  if (!wrap || !tbody) return;
  wrap.classList.remove("hidden");
  tbody.innerHTML = results.map((r, i) => {
    const score = r.trust_score || 0;
    const cls = score >= 70 ? "green" : score >= 40 ? "yellow" : "red";
    return `
      <tr>
        <td>${i + 1}</td>
        <td><a href="${r.url}" target="_blank" style="color:var(--cyan)">${r.name || r.url}</a></td>
        <td><span class="score-pill ${cls}">${Math.round(score)}/100</span></td>
        <td>${r.trust_level || (r.error ? "Error" : "—")}</td>
        <td>${(r.insight && r.insight.tech_tags || []).slice(0, 2).map(t => `<span class="tag">${t}</span>`).join("") || "—"}</td>
        <td style="color:${r.security && r.security.risk_level === 'HIGH' ? 'var(--red)' : r.security && r.security.risk_level === 'MEDIUM' ? 'var(--yellow)' : 'var(--green)'}">${r.security ? r.security.risk_level : "—"}</td>
        <td style="font-size:12px;color:var(--text2);max-width:200px;overflow:hidden;text-overflow:ellipsis">${r.recommendation || r.error || "—"}</td>
      </tr>
    `;
  }).join("");
  document.getElementById("batch-count").textContent = results.length + " startups analyzed";
}

function exportBatchCSV() {
  if (!batchResults.length) return;
  const headers = ["Name", "URL", "Trust Score", "Trust Level", "Risk", "Recommendation"];
  const rows = batchResults.map(r => [
    r.name || "", r.url || "", r.trust_score || 0, r.trust_level || "",
    r.security ? r.security.risk_level : "", r.recommendation || r.error || ""
  ]);
  const csv = [headers, ...rows].map(r => r.map(v => `"${v}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "pulse-x-batch-results.csv";
  a.click();
}

window.PulseBatch = { initBatch, runBatchManual, exportBatchCSV };

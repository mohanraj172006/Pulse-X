# Pulse X — Enterprise Startup Trust Intelligence

## Quick Start

### Backend
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your credentials
uvicorn main:app --reload --port 8000
```

### Frontend
Open `frontend/index.html` in your browser.

## API Endpoints
- `POST /api/startups/verify` — verify a startup
- `POST /api/batch/verify` — batch analyze up to 20 startups
- `WS /api/monitor/{startup_id}` — real-time IoT alerts
- `POST /api/feedback/` — submit score correction
- `GET /api/health` — health check

## Team Roles
- Person 1: Frontend (frontend/)
- Person 2: IoT Sensors (backend/app/iot/)
- Person 3: AI Agents (backend/app/agents/)
- Person 4: Backend/Security (backend/app/api/, backend/app/services/)

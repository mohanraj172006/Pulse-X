import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import startup, batch, monitor, feedback, health
from app.database import connect_db, disconnect_db
from app.redis_client import init_redis, close_redis
from app.utils.logger import setup_logging

setup_logging()
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_db()
    await init_redis()
    from app.iot.monitor_service import start_all_sensors
    import asyncio
    asyncio.create_task(start_all_sensors())
    logger.info("Pulse X started")
    yield
    await disconnect_db()
    await close_redis()

app = FastAPI(title="Pulse X API", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(health.router, prefix="/api", tags=["Health"])
app.include_router(startup.router, prefix="/api/startups", tags=["Startups"])
app.include_router(batch.router, prefix="/api/batch", tags=["Batch"])
app.include_router(monitor.router, prefix="/api/monitor", tags=["Monitor"])
app.include_router(feedback.router, prefix="/api/feedback", tags=["Feedback"])

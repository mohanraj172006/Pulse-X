import logging
import json
from datetime import datetime
from fastapi import WebSocket
from typing import Dict, List

logger = logging.getLogger(__name__)

class WebSocketManager:
    def __init__(self):
        self.active: Dict[str, List[WebSocket]] = {}

    async def connect(self, startup_id: str, ws: WebSocket):
        await ws.accept()
        if startup_id not in self.active:
            self.active[startup_id] = []
        self.active[startup_id].append(ws)
        logger.info("WS connected: %s", startup_id)

    def disconnect(self, startup_id: str, ws: WebSocket):
        if startup_id in self.active:
            self.active[startup_id] = [w for w in self.active[startup_id] if w != ws]

    async def broadcast(self, startup_id: str, data: dict):
        if startup_id not in self.active:
            return
        message = json.dumps({**data, "timestamp": datetime.utcnow().isoformat()})
        dead = []
        for ws in self.active[startup_id]:
            try:
                await ws.send_text(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(startup_id, ws)

    async def broadcast_all(self, data: dict):
        message = json.dumps({**data, "timestamp": datetime.utcnow().isoformat()})
        for startup_id, connections in self.active.items():
            for ws in connections:
                try:
                    await ws.send_text(message)
                except Exception:
                    pass

ws_manager = WebSocketManager()

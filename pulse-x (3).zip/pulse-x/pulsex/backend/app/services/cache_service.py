import json
import logging
from app.redis_client import get_redis

logger = logging.getLogger(__name__)
CACHE_TTL = 3600

async def get_cached(key: str):
    r = get_redis()
    if r is None:
        return None
    try:
        val = await r.get(key)
        return json.loads(val) if val else None
    except Exception as e:
        logger.warning("Cache get error: %s", e)
        return None

async def set_cached(key: str, value: dict, ttl: int = CACHE_TTL):
    r = get_redis()
    if r is None:
        return
    try:
        await r.setex(key, ttl, json.dumps(value, default=str))
    except Exception as e:
        logger.warning("Cache set error: %s", e)

async def invalidate(key: str):
    r = get_redis()
    if r is None:
        return
    try:
        await r.delete(key)
    except Exception as e:
        logger.warning("Cache delete error: %s", e)

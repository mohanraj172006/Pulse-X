import logging
from app.database import get_db

logger = logging.getLogger(__name__)

DEFAULT_WEIGHTS = {"verification": 0.30, "insight": 0.30, "security": 0.40}

async def get_enterprise_weights(enterprise_id: str) -> dict:
    try:
        db = get_db()
        if db is None:
            return DEFAULT_WEIGHTS
        doc = await db.enterprise_weights.find_one({"enterprise_id": enterprise_id})
        if doc:
            return {"verification": doc.get("v", 0.30), "insight": doc.get("i", 0.30), "security": doc.get("s", 0.40)}
    except Exception as e:
        logger.warning("Failed to get enterprise weights: %s", e)
    return DEFAULT_WEIGHTS

def calculate_trust_score(v_score: float, i_score: float, s_score: float, enterprise_id: str = "default") -> float:
    weights = DEFAULT_WEIGHTS
    score = (v_score * weights["verification"]) + (i_score * weights["insight"]) + (s_score * weights["security"])
    return round(max(0.0, min(100.0, score)), 2)

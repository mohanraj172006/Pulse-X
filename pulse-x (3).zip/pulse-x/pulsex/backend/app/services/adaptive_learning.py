import logging
from datetime import datetime
from app.database import get_db

logger = logging.getLogger(__name__)

async def record_feedback(startup_id: str, predicted: float, actual: float, reason: str, enterprise_id: str):
    db = get_db()
    if db is None:
        return
    error = actual - predicted
    correction = {
        "startup_id": startup_id,
        "predicted_score": predicted,
        "actual_score": actual,
        "error": error,
        "reason": reason or "",
        "enterprise_id": enterprise_id,
        "created_at": datetime.utcnow(),
    }
    await db.feedback.insert_one(correction)
    await adjust_weights(enterprise_id, error, reason or "")
    logger.info("Feedback recorded for enterprise %s, error: %.2f", enterprise_id, error)

async def adjust_weights(enterprise_id: str, error: float, reason: str):
    db = get_db()
    if db is None:
        return
    doc = await db.enterprise_weights.find_one({"enterprise_id": enterprise_id})
    if doc:
        v = doc.get("v", 0.30)
        i = doc.get("i", 0.30)
        s = doc.get("s", 0.40)
    else:
        v, i, s = 0.30, 0.30, 0.40
    reason_lower = reason.lower()
    adjustment = 0.03
    if error > 10:
        if "linkedin" in reason_lower or "verification" in reason_lower:
            v = max(0.10, v - adjustment)
            i = min(0.60, i + adjustment)
        elif "security" in reason_lower or "ssl" in reason_lower:
            s = max(0.15, s - adjustment)
            v = min(0.60, v + adjustment)
        else:
            i = min(0.60, i + adjustment)
            s = max(0.15, s - adjustment)
    elif error < -10:
        s = min(0.60, s + adjustment)
        i = max(0.10, i - adjustment)
    total = v + i + s
    v, i, s = v/total, i/total, s/total
    await db.enterprise_weights.update_one(
        {"enterprise_id": enterprise_id},
        {"$set": {"v": round(v, 4), "i": round(i, 4), "s": round(s, 4), "updated_at": datetime.utcnow()}},
        upsert=True,
    )

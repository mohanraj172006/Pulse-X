# import logging
# import motor.motor_asyncio
# from app.config import settings

# logger = logging.getLogger(__name__)
# client = None
# db = None

# async def connect_db():
#     global client, db
#     client = motor.motor_asyncio.AsyncIOMotorClient(settings.MONGO_URI)
#     db = client[settings.MONGO_DB]
#     await db.startups.create_index("url")
#     await db.startups.create_index("created_at")
#     await db.alerts.create_index("startup_id")
#     await db.feedback.create_index("enterprise_id")
#     logger.info("MongoDB connected")

# async def disconnect_db():
#     global client
#     if client:
#         client.close()

# def get_db():
#     return db

import logging

logger = logging.getLogger(__name__)

db = None

class FakeDB:
    def __init__(self):
        self.data = {}
    
    def __getattr__(self, name):
        if name not in self.data:
            self.data[name] = FakeCollection(name)
        return self.data[name]

class FakeCollection:
    def __init__(self, name):
        self.name = name
        self._docs = []
    
    async def insert_one(self, doc):
        import uuid
        doc["_id"] = str(uuid.uuid4())
        self._docs.append(doc)
        class Result:
            inserted_id = doc["_id"]
        return Result()
    
    async def find_one(self, query):
        for doc in self._docs:
            if all(doc.get(k) == v for k,v in query.items()):
                return doc
        return None
    
    def find(self, query={}):
        return FakeCursor(self._docs)
    
    async def update_one(self, query, update, upsert=False):
        pass
    
    async def create_index(self, *args, **kwargs):
        pass

class FakeCursor:
    def __init__(self, docs):
        self._docs = docs
    
    def sort(self, *args):
        return self
    
    def limit(self, n):
        return self
    
    async def to_list(self, n):
        return self._docs[:n]

async def connect_db():
    global db
    db = FakeDB()
    logger.info("Using in-memory database (no MongoDB)")

async def disconnect_db():
    pass

def get_db():
    return db
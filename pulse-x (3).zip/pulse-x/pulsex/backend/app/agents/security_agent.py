import logging
import asyncio
import ssl
import socket
import hashlib
from datetime import datetime, timezone
from typing import List
import httpx
import dns.resolver
from app.config import settings
from app.models.startup import SecurityResult
from app.utils.validators import extract_domain

logger = logging.getLogger(__name__)

async def check_ssl(domain: str) -> dict:
    result = {"valid": False, "expiry_days": None, "flags": []}
    try:
        ctx = ssl.create_default_context()
        loop = asyncio.get_event_loop()
        def _check():
            with socket.create_connection((domain, 443), timeout=10) as sock:
                with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    expiry_str = cert["notAfter"]
                    expiry_dt = datetime.strptime(expiry_str, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                    days_left = (expiry_dt - datetime.now(timezone.utc)).days
                    return {"valid": days_left > 0, "expiry_days": days_left, "flags": []}
        result = await loop.run_in_executor(None, _check)
        if result["expiry_days"] is not None and result["expiry_days"] < 30:
            result["flags"].append(f"SSL certificate expires in {result['expiry_days']} days")
    except ssl.SSLError:
        result["flags"].append("SSL certificate invalid or self-signed")
    except (socket.timeout, ConnectionRefusedError, OSError):
        result["flags"].append("SSL port 443 not reachable")
    except Exception as e:
        result["flags"].append(f"SSL check failed: {str(e)[:100]}")
    return result

async def check_credential_leaks(domain: str) -> int:
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"https://haveibeenpwned.com/api/v3/breacheddomain/{domain}",
                headers={
                    "hibp-api-key": settings.HIBP_API_KEY,
                    "User-Agent": "PulseX-TrustEngine/1.0",
                },
            )
            if resp.status_code == 200:
                return len(resp.json())
            elif resp.status_code == 404:
                return 0
    except Exception as e:
        logger.warning("HIBP check error: %s", e)
    return 0

async def check_dns(domain: str) -> dict:
    result = {"anomaly": False, "flags": []}
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 5
        a_records = resolver.resolve(domain, "A")
        ips = [r.address for r in a_records]
        suspicious_ranges = ["185.220.", "193.142.", "45.142."]
        for ip in ips:
            if any(ip.startswith(r) for r in suspicious_ranges):
                result["anomaly"] = True
                result["flags"].append(f"Suspicious IP range detected: {ip}")
    except dns.resolver.NXDOMAIN:
        result["anomaly"] = True
        result["flags"].append("Domain does not resolve (NXDOMAIN)")
    except Exception as e:
        logger.warning("DNS check error: %s", e)
    return result

async def check_email_security(domain: str) -> dict:
    result = {"spf": False, "dkim": False, "dmarc": False, "flags": []}
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 5
        try:
            answers = resolver.resolve(domain, "TXT")
            for rdata in answers:
                txt = str(rdata)
                if "v=spf1" in txt:
                    result["spf"] = True
        except:
            result["flags"].append("SPF record missing")
        try:
            answers = resolver.resolve(f"_dmarc.{domain}", "TXT")
            for rdata in answers:
                if "v=DMARC1" in str(rdata):
                    result["dmarc"] = True
        except:
            result["flags"].append("DMARC record missing")
        try:
            answers = resolver.resolve(f"default._domainkey.{domain}", "TXT")
            for rdata in answers:
                if "v=DKIM1" in str(rdata):
                    result["dkim"] = True
        except:
            pass
    except Exception as e:
        logger.warning("Email security check error: %s", e)
    return result

async def check_domain_age(domain: str) -> dict:
    result = {"age_days": None, "flags": []}
    try:
        import whois as python_whois
        loop = asyncio.get_event_loop()
        def _whois():
            return python_whois.whois(domain)
        w = await asyncio.wait_for(loop.run_in_executor(None, _whois), timeout=15)
        if w and w.creation_date:
            cd = w.creation_date
            if isinstance(cd, list):
                cd = cd[0]
            if cd:
                if cd.tzinfo is None:
                    cd = cd.replace(tzinfo=timezone.utc)
                age = (datetime.now(timezone.utc) - cd).days
                result["age_days"] = age
                if age < 180:
                    result["flags"].append(f"Domain very new: only {age} days old")
    except Exception as e:
        logger.warning("Domain age check error: %s", e)
    return result

async def check_open_ports(domain: str) -> List[int]:
    open_ports = []
    ports_to_check = [22, 80, 443, 8080, 3389, 21, 25]
    async def _check_port(port):
        try:
            loop = asyncio.get_event_loop()
            def _connect():
                s = socket.socket()
                s.settimeout(2)
                result = s.connect_ex((domain, port))
                s.close()
                return result
            r = await loop.run_in_executor(None, _connect)
            if r == 0:
                return port
        except:
            pass
        return None
    results = await asyncio.gather(*[_check_port(p) for p in ports_to_check])
    open_ports = [p for p in results if p is not None]
    return open_ports

async def run_security(url: str) -> SecurityResult:
    from app.utils.validators import extract_domain
    domain = extract_domain(url)
    ssl_data, credential_leaks, dns_data, email_data, domain_age, open_ports = await asyncio.gather(
        check_ssl(domain),
        check_credential_leaks(domain),
        check_dns(domain),
        check_email_security(domain),
        check_domain_age(domain),
        check_open_ports(domain),
    )
    all_flags = []
    all_flags.extend(ssl_data.get("flags", []))
    all_flags.extend(dns_data.get("flags", []))
    all_flags.extend(email_data.get("flags", []))
    all_flags.extend(domain_age.get("flags", []))
    if credential_leaks > 0:
        all_flags.append(f"{credential_leaks} credential breach(es) found via HIBP")
    suspicious_ports = [p for p in open_ports if p in [22, 3389, 21, 25]]
    if suspicious_ports:
        all_flags.append(f"Potentially risky open ports: {suspicious_ports}")
    score = 100.0
    if not ssl_data.get("valid"):
        score -= 25
    if domain_age.get("age_days") and domain_age["age_days"] < 180:
        score -= 20
    if credential_leaks > 0:
        score -= min(credential_leaks * 10, 30)
    if dns_data.get("anomaly"):
        score -= 15
    if not email_data.get("spf"):
        score -= 5
    if not email_data.get("dmarc"):
        score -= 5
    if len(suspicious_ports) > 0:
        score -= 10
    score = max(0.0, min(100.0, score))
    if score >= 70:
        risk = "LOW"
    elif score >= 40:
        risk = "MEDIUM"
    else:
        risk = "HIGH"
    return SecurityResult(
        ssl_valid=ssl_data.get("valid", False),
        ssl_expiry_days=ssl_data.get("expiry_days"),
        domain_age_days=domain_age.get("age_days"),
        credential_leaks=credential_leaks,
        open_ports=open_ports,
        dns_anomaly=dns_data.get("anomaly", False),
        email_spf=email_data.get("spf", False),
        email_dkim=email_data.get("dkim", False),
        email_dmarc=email_data.get("dmarc", False),
        risk_level=risk,
        flags=all_flags,
        score=round(score, 2),
    )

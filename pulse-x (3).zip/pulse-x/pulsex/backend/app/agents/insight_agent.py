import logging
import asyncio
import httpx
import re
from bs4 import BeautifulSoup
from app.models.startup import InsightResult

logger = logging.getLogger(__name__)

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"}

TECH_KEYWORDS = {
    "AI/ML": ["artificial intelligence","machine learning","deep learning","neural network","nlp","computer vision","llm","transformer","bert","gpt"],
    "FinTech": ["fintech","payment","banking","lending","insurance","blockchain","crypto","defi","neobank"],
    "HealthTech": ["healthtech","medtech","telemedicine","ehr","clinical","pharma","biotech","genomics"],
    "EdTech": ["edtech","e-learning","lms","mooc","upskilling","courseware"],
    "SaaS": ["saas","cloud","subscription","platform","api","microservices","devops","kubernetes","docker"],
    "Cybersecurity": ["cybersecurity","security","soc","siem","zero trust","threat","vulnerability","pen test"],
    "IoT": ["iot","edge computing","embedded","sensor","firmware","raspberry","arduino","mqtt"],
    "E-Commerce": ["ecommerce","marketplace","shopify","d2c","retail tech","logistics"],
}

MATURITY_SIGNALS = {
    "Scale": ["series c","series d","ipo","unicorn","billion","10000 employees","global","enterprise"],
    "Growth": ["series b","series a","million","500 employees","expansion","international"],
    "Early": ["seed","pre-seed","early stage","startup","100 employees","founding"],
    "Idea": ["prototype","mvp","stealth","pre-launch","beta"],
}

async def scrape_startup_content(url: str) -> str:
    try:
        async with httpx.AsyncClient(headers=HEADERS, timeout=15, follow_redirects=True) as client:
            resp = await client.get(url)
            if resp.status_code == 200:
                soup = BeautifulSoup(resp.text, "lxml")
                for tag in soup(["script","style","nav","footer","header"]):
                    tag.decompose()
                return soup.get_text(" ", strip=True)[:5000]
    except Exception as e:
        logger.warning("Content scrape error: %s", e)
    return ""

def classify_tech_tags(text: str) -> list:
    text_lower = text.lower()
    tags = []
    for category, keywords in TECH_KEYWORDS.items():
        if any(kw in text_lower for kw in keywords):
            tags.append(category)
    return tags if tags else ["General Tech"]

def classify_maturity(text: str) -> str:
    text_lower = text.lower()
    for level, signals in MATURITY_SIGNALS.items():
        if any(s in text_lower for s in signals):
            return level
    return "Early"

def classify_industry(text: str) -> str:
    text_lower = text.lower()
    industry_map = {
        "Financial Services": ["fintech","finance","banking","payment","insurance"],
        "Healthcare": ["health","medical","clinical","pharma","hospital"],
        "Education": ["education","learning","school","university","training"],
        "Technology": ["software","saas","cloud","platform","tech"],
        "Manufacturing": ["manufacturing","factory","production","supply chain"],
        "Retail": ["retail","ecommerce","marketplace","consumer"],
    }
    for industry, keywords in industry_map.items():
        if any(k in text_lower for k in keywords):
            return industry
    return "Technology"

def calculate_relevance_score(tags: list, maturity: str, text: str) -> float:
    score = 50.0
    score += len(tags) * 8
    maturity_bonus = {"Scale": 30, "Growth": 25, "Early": 15, "Idea": 5}
    score += maturity_bonus.get(maturity, 10)
    if len(text) > 1000:
        score += 10
    return min(100.0, score)

async def run_insight(url: str) -> InsightResult:
    content = await scrape_startup_content(url)
    if not content:
        return InsightResult(score=30.0, maturity_level="Unknown", innovation_category="Unknown")
    tags = classify_tech_tags(content)
    maturity = classify_maturity(content)
    industry = classify_industry(content)
    category = tags[0] if tags else "General Tech"
    relevance = calculate_relevance_score(tags, maturity, content)
    words = content.split()
    summary = " ".join(words[:50]) + "..." if len(words) > 50 else content
    score = relevance
    return InsightResult(
        innovation_category=category,
        tech_tags=tags,
        maturity_level=maturity,
        relevance_score=round(relevance, 2),
        description_summary=summary,
        industry=industry,
        score=round(score, 2),
    )

import logging
import asyncio
from datetime import datetime
from app.agents.verification_agent import run_verification
from app.agents.insight_agent import run_insight
from app.agents.security_agent import run_security
from app.services.trust_score import calculate_trust_score
from app.utils.formatters import format_trust_level, get_recommendation
from app.utils.validators import extract_domain

logger = logging.getLogger(__name__)

async def run_all_agents(url: str, name: str = None, enterprise_id: str = "default") -> dict:
    domain = extract_domain(url)
    company_name = name or domain.split(".")[0].title()
    logger.info("Running all agents for: %s", url)
    verification, insight, security = await asyncio.gather(
        run_verification(url, company_name),
        run_insight(url),
        run_security(url),
        return_exceptions=True,
    )
    if isinstance(verification, Exception):
        logger.error("Verification agent failed: %s", verification)
        from app.models.startup import VerificationResult
        verification = VerificationResult(score=0.0, discrepancies=["Verification failed"])
    if isinstance(insight, Exception):
        logger.error("Insight agent failed: %s", insight)
        from app.models.startup import InsightResult
        insight = InsightResult(score=30.0, maturity_level="Unknown")
    if isinstance(security, Exception):
        logger.error("Security agent failed: %s", security)
        from app.models.startup import SecurityResult
        security = SecurityResult(score=0.0, risk_level="UNKNOWN")
    trust_score = calculate_trust_score(
        verification.score,
        insight.score,
        security.score,
        enterprise_id=enterprise_id,
    )
    trust_info = format_trust_level(trust_score)
    all_sources = list(set(verification.sources))
    return {
        "name": company_name,
        "url": url,
        "trust_score": round(trust_score, 2),
        "trust_level": trust_info["level"],
        "trust_color": trust_info["color"],
        "trust_emoji": trust_info["emoji"],
        "recommendation": get_recommendation(trust_score),
        "verification": verification.model_dump(),
        "insight": insight.model_dump(),
        "security": security.model_dump(),
        "sources": all_sources,
        "enterprise_id": enterprise_id,
        "created_at": datetime.utcnow().isoformat(),
    }

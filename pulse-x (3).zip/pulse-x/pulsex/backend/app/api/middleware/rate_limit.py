from fastapi import Request, HTTPException
from collections import defaultdict
import time

request_counts = defaultdict(list)

async def rate_limit_middleware(request: Request, call_next):
    ip = request.client.host
    now = time.time()
    request_counts[ip] = [t for t in request_counts[ip] if now - t < 60]
    if len(request_counts[ip]) > 100:
        raise HTTPException(status_code=429, detail="Too many requests")
    request_counts[ip].append(now)
    return await call_next(request)

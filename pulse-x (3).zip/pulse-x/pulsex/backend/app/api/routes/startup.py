import logging
from fastapi import APIRouter, HTTPException
from bson import ObjectId
from datetime import datetime
from app.models.startup import StartupVerifyRequest
from app.agents.orchestrator import run_all_agents
from app.services.cache_service import get_cached, set_cached
from app.database import get_db
from app.utils.validators import is_valid_url, extract_domain

logger = logging.getLogger(__name__)
router = APIRouter()

@router.post("/verify")
async def verify_startup(req: StartupVerifyRequest):
    if not is_valid_url(req.url):
        raise HTTPException(status_code=400, detail="Invalid URL provided")
    cache_key = f"trust:{req.url}:{req.enterprise_id}"
    cached = await get_cached(cache_key)
    if cached:
        return {**cached, "from_cache": True}
    result = await run_all_agents(req.url, req.name, req.enterprise_id)
    db = get_db()
    if db:
        domain = extract_domain(req.url)
        doc = {**result, "created_at": datetime.utcnow()}
        inserted = await db.startups.insert_one(doc)
        result["id"] = str(inserted.inserted_id)
        await db.monitoring.update_one(
            {"domain": domain},
            {"$set": {"domain": domain, "startup_id": str(inserted.inserted_id), "url": req.url, "enterprise_id": req.enterprise_id}},
            upsert=True,
        )
    await set_cached(cache_key, result)
    return result

@router.get("/{startup_id}")
async def get_startup(startup_id: str):
    db = get_db()
    if not db:
        raise HTTPException(status_code=503, detail="Database unavailable")
    try:
        doc = await db.startups.find_one({"_id": ObjectId(startup_id)})
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid startup ID")
    if not doc:
        raise HTTPException(status_code=404, detail="Startup not found")
    doc["id"] = str(doc.pop("_id"))
    return doc

@router.get("/{startup_id}/health-card")
async def get_health_card(startup_id: str):
    db = get_db()
    if not db:
        raise HTTPException(status_code=503, detail="Database unavailable")
    try:
        doc = await db.startups.find_one({"_id": ObjectId(startup_id)})
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid startup ID")
    if not doc:
        raise HTTPException(status_code=404, detail="Startup not found")
    doc["id"] = str(doc.pop("_id"))
    return {
        "startup": doc.get("name"),
        "url": doc.get("url"),
        "trust_score": doc.get("trust_score"),
        "trust_level": doc.get("trust_level"),
        "recommendation": doc.get("recommendation"),
        "verification": doc.get("verification", {}),
        "insight": doc.get("insight", {}),
        "security": doc.get("security", {}),
        "sources": doc.get("sources", []),
        "generated_at": doc.get("created_at"),
    }

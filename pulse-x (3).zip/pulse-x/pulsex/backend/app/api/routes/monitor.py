import logging
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.services.websocket_manager import ws_manager

logger = logging.getLogger(__name__)
router = APIRouter()

@router.websocket("/{startup_id}")
async def monitor_startup(websocket: WebSocket, startup_id: str):
    await ws_manager.connect(startup_id, websocket)
    try:
        while True:
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(startup_id, websocket)
        logger.info("WS disconnected: %s", startup_id)

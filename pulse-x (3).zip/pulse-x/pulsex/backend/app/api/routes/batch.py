import logging
import asyncio
from fastapi import APIRouter, HTTPException
from app.models.startup import BatchVerifyRequest
from app.agents.orchestrator import run_all_agents
from app.utils.validators import is_valid_url

logger = logging.getLogger(__name__)
router = APIRouter()

@router.post("/verify")
async def batch_verify(req: BatchVerifyRequest):
    if not req.startups:
        raise HTTPException(status_code=400, detail="No startups provided")
    if len(req.startups) > 20:
        raise HTTPException(status_code=400, detail="Maximum 20 startups per batch")
    tasks = [
        run_all_agents(s.url, s.name, req.enterprise_id)
        for s in req.startups
        if is_valid_url(s.url)
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    output = []
    for i, r in enumerate(results):
        if isinstance(r, Exception):
            output.append({"url": req.startups[i].url, "error": str(r), "trust_score": 0})
        else:
            output.append(r)
    return {"results": output, "total": len(output), "enterprise_id": req.enterprise_id}

import logging
from fastapi import APIRouter, HTTPException
from app.models.feedback import FeedbackRequest
from app.services.adaptive_learning import record_feedback
from app.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter()

@router.post("/")
async def submit_feedback(req: FeedbackRequest):
    if not 0 <= req.actual_score <= 100:
        raise HTTPException(status_code=400, detail="Score must be between 0 and 100")
    await record_feedback(req.startup_id, req.predicted_score, req.actual_score, req.reason, req.enterprise_id)
    return {"status": "ok", "message": "Feedback recorded. Model weights updated."}

@router.get("/insights/{enterprise_id}")
async def get_feedback_insights(enterprise_id: str):
    db = get_db()
    if not db:
        raise HTTPException(status_code=503, detail="Database unavailable")
    corrections = await db.feedback.find({"enterprise_id": enterprise_id}).sort("created_at", -1).limit(50).to_list(50)
    weights = await db.enterprise_weights.find_one({"enterprise_id": enterprise_id})
    return {
        "enterprise_id": enterprise_id,
        "total_corrections": len(corrections),
        "current_weights": {
            "verification": weights.get("v", 0.30) if weights else 0.30,
            "insight": weights.get("i", 0.30) if weights else 0.30,
            "security": weights.get("s", 0.40) if weights else 0.40,
        },
    }

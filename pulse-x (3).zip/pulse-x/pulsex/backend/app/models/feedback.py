from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class FeedbackRequest(BaseModel):
    startup_id: str
    predicted_score: float
    actual_score: float
    reason: Optional[str] = None
    enterprise_id: str = "default"

class FeedbackRecord(BaseModel):
    id: Optional[str] = None
    startup_id: str
    predicted_score: float
    actual_score: float
    error: float = 0.0
    reason: Optional[str] = None
    enterprise_id: str = "default"
    created_at: datetime = Field(default_factory=datetime.utcnow)

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class StartupVerifyRequest(BaseModel):
    url: str
    name: Optional[str] = None
    enterprise_id: Optional[str] = "default"

class BatchVerifyRequest(BaseModel):
    startups: List[StartupVerifyRequest]
    enterprise_id: Optional[str] = "default"

class VerificationResult(BaseModel):
    employee_count_claimed: Optional[str] = None
    employee_count_verified: Optional[str] = None
    founded_year_claimed: Optional[str] = None
    founded_year_verified: Optional[str] = None
    linkedin_presence: bool = False
    linkedin_followers: Optional[int] = None
    news_mentions: int = 0
    mca_registered: bool = False
    mca_cin: Optional[str] = None
    mca_status: Optional[str] = None
    discrepancies: List[str] = []
    sources: List[str] = []
    score: float = 0.0

class InsightResult(BaseModel):
    innovation_category: Optional[str] = None
    tech_tags: List[str] = []
    maturity_level: Optional[str] = None
    relevance_score: float = 0.0
    description_summary: Optional[str] = None
    industry: Optional[str] = None
    score: float = 0.0

class SecurityResult(BaseModel):
    ssl_valid: bool = False
    ssl_expiry_days: Optional[int] = None
    domain_age_days: Optional[int] = None
    credential_leaks: int = 0
    open_ports: List[int] = []
    dns_anomaly: bool = False
    email_spf: bool = False
    email_dkim: bool = False
    email_dmarc: bool = False
    risk_level: str = "UNKNOWN"
    flags: List[str] = []
    score: float = 0.0

class StartupHealthCard(BaseModel):
    id: Optional[str] = None
    name: str
    url: str
    trust_score: float
    trust_level: str
    trust_color: str
    recommendation: str
    verification: VerificationResult
    insight: InsightResult
    security: SecurityResult
    sources: List[str] = []
    enterprise_id: str = "default"
    created_at: datetime = Field(default_factory=datetime.utcnow)

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from enum import Enum

class AlertType(str, Enum):
    SSL_EXPIRING = "SSL_EXPIRING"
    SSL_INVALID = "SSL_INVALID"
    DOMAIN_EXPIRING = "DOMAIN_EXPIRING"
    DOMAIN_CHANGED = "DOMAIN_CHANGED"
    CREDENTIAL_LEAK = "CREDENTIAL_LEAK"
    DNS_ANOMALY = "DNS_ANOMALY"
    EMAIL_SECURITY = "EMAIL_SECURITY"
    IOT_MOTION = "IOT_MOTION"

class AlertSeverity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

class Alert(BaseModel):
    id: Optional[str] = None
    startup_id: str
    startup_url: str
    alert_type: AlertType
    severity: AlertSeverity
    message: str
    details: dict = {}
    resolved: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    MONGO_URI: str = "mongodb://localhost:27017"
    MONGO_DB: str = "pulsex"
    REDIS_URL: str = "redis://localhost:6379"
    SECRET_KEY: str = "change-this"
    LINKEDIN_USERNAME: str = ""
    LINKEDIN_PASSWORD: str = ""
    HIBP_API_KEY: str = "lrDKSdS2qaVi4Sd7bBT6dg"
    VIRUSTOTAL_API_KEY: str = ""
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    DEBUG: bool = True

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()

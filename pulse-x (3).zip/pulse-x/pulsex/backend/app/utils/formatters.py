from datetime import datetime

def format_trust_level(score: float) -> dict:
    if score >= 70:
        return {"level": "LOW RISK", "color": "green", "emoji": "🟢"}
    elif score >= 40:
        return {"level": "MEDIUM RISK", "color": "yellow", "emoji": "🟡"}
    return {"level": "HIGH RISK", "color": "red", "emoji": "🔴"}

def get_recommendation(score: float) -> str:
    if score >= 70:
        return "Safe to proceed with partnership evaluation."
    elif score >= 40:
        return "Proceed with caution. Request additional documentation."
    return "High risk. Investigate thoroughly before engagement."

import logging, sys

def setup_logging():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s", handlers=[logging.StreamHandler(sys.stdout)])
    for lib in ["motor","httpx","urllib3"]:
        logging.getLogger(lib).setLevel(logging.WARNING)

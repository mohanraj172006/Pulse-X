import asyncio, ssl, socket, logging
from datetime import datetime, timezone
from app.services.websocket_manager import ws_manager
from app.database import get_db

logger = logging.getLogger(__name__)

async def check_ssl_expiry(domain: str) -> dict:
    try:
        ctx = ssl.create_default_context()
        loop = asyncio.get_event_loop()
        def _check():
            with socket.create_connection((domain, 443), timeout=10) as s:
                with ctx.wrap_socket(s, server_hostname=domain) as ss:
                    cert = ss.getpeercert()
                    exp = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                    return (exp - datetime.now(timezone.utc)).days
        days = await loop.run_in_executor(None, _check)
        return {"valid": days > 0, "expiry_days": days}
    except Exception as e:
        return {"valid": False, "expiry_days": None, "error": str(e)}

async def run_ssl_sensor():
    while True:
        try:
            db = get_db()
            if db:
                monitored = await db.monitoring.find({}).to_list(100)
                for item in monitored:
                    domain = item.get("domain")
                    startup_id = str(item.get("_id", item.get("startup_id", "")))
                    if domain:
                        result = await check_ssl_expiry(domain)
                        if not result.get("valid") or (result.get("expiry_days") and result["expiry_days"] < 30):
                            severity = "CRITICAL" if not result.get("valid") else "HIGH"
                            await ws_manager.broadcast(startup_id, {
                                "type": "SSL_EXPIRING",
                                "severity": severity,
                                "domain": domain,
                                "message": f"SSL certificate expires in {result.get('expiry_days', 0)} days",
                                "days_left": result.get("expiry_days"),
                            })
        except Exception as e:
            logger.warning("SSL sensor error: %s", e)
        await asyncio.sleep(6 * 3600)

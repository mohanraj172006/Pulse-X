import asyncio, logging
import dns.resolver
from app.services.websocket_manager import ws_manager
from app.database import get_db

logger = logging.getLogger(__name__)

async def run_email_sensor():
    while True:
        try:
            db = get_db()
            if db:
                monitored = await db.monitoring.find({}).to_list(100)
                for item in monitored:
                    domain = item.get("domain")
                    startup_id = str(item.get("_id", item.get("startup_id", "")))
                    if domain:
                        try:
                            flags = []
                            resolver = dns.resolver.Resolver()
                            resolver.timeout = 5
                            spf_found = False
                            try:
                                answers = resolver.resolve(domain, "TXT")
                                for r in answers:
                                    if "v=spf1" in str(r):
                                        spf_found = True
                            except: pass
                            if not spf_found:
                                flags.append("SPF record missing")
                            dmarc_found = False
                            try:
                                answers = resolver.resolve(f"_dmarc.{domain}", "TXT")
                                for r in answers:
                                    if "v=DMARC1" in str(r):
                                        dmarc_found = True
                            except: pass
                            if not dmarc_found:
                                flags.append("DMARC record missing")
                            if flags:
                                await ws_manager.broadcast(startup_id, {
                                    "type": "EMAIL_SECURITY",
                                    "severity": "MEDIUM",
                                    "domain": domain,
                                    "message": f"Email security issues: {', '.join(flags)}",
                                    "flags": flags,
                                })
                        except Exception as e:
                            logger.warning("Email sensor error for %s: %s", domain, e)
        except Exception as e:
            logger.warning("Email sensor error: %s", e)
        await asyncio.sleep(7 * 24 * 3600)

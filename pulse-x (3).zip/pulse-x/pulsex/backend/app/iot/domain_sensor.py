import asyncio, logging
from datetime import datetime, timezone
from app.services.websocket_manager import ws_manager
from app.database import get_db

logger = logging.getLogger(__name__)

async def run_domain_sensor():
    while True:
        try:
            db = get_db()
            if db:
                monitored = await db.monitoring.find({}).to_list(100)
                for item in monitored:
                    domain = item.get("domain")
                    startup_id = str(item.get("_id", item.get("startup_id", "")))
                    if domain:
                        try:
                            import whois as pw
                            loop = asyncio.get_event_loop()
                            w = await asyncio.wait_for(loop.run_in_executor(None, pw.whois, domain), timeout=15)
                            if w and w.expiration_date:
                                exp = w.expiration_date
                                if isinstance(exp, list): exp = exp[0]
                                if exp:
                                    if exp.tzinfo is None: exp = exp.replace(tzinfo=timezone.utc)
                                    days_left = (exp - datetime.now(timezone.utc)).days
                                    if days_left < 30:
                                        await ws_manager.broadcast(startup_id, {
                                            "type": "DOMAIN_EXPIRING",
                                            "severity": "HIGH",
                                            "domain": domain,
                                            "message": f"Domain expires in {days_left} days",
                                            "days_left": days_left,
                                        })
                        except Exception as e:
                            logger.warning("Domain check error for %s: %s", domain, e)
        except Exception as e:
            logger.warning("Domain sensor error: %s", e)
        await asyncio.sleep(24 * 3600)

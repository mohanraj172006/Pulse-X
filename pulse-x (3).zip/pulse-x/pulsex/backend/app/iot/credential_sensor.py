import asyncio, logging, httpx
from app.config import settings
from app.services.websocket_manager import ws_manager
from app.database import get_db

logger = logging.getLogger(__name__)

async def run_credential_sensor():
    while True:
        try:
            db = get_db()
            if db:
                monitored = await db.monitoring.find({}).to_list(100)
                for item in monitored:
                    domain = item.get("domain")
                    startup_id = str(item.get("_id", item.get("startup_id", "")))
                    prev_count = item.get("credential_leaks", 0)
                    if domain:
                        try:
                            async with httpx.AsyncClient(timeout=10) as client:
                                resp = await client.get(
                                    f"https://haveibeenpwned.com/api/v3/breacheddomain/{domain}",
                                    headers={"hibp-api-key": settings.HIBP_API_KEY, "User-Agent": "PulseX/1.0"},
                                )
                                current_count = len(resp.json()) if resp.status_code == 200 else 0
                                if current_count > prev_count:
                                    await ws_manager.broadcast(startup_id, {
                                        "type": "CREDENTIAL_LEAK",
                                        "severity": "CRITICAL",
                                        "domain": domain,
                                        "message": f"New credential breach detected: {current_count} total breaches",
                                        "breach_count": current_count,
                                    })
                                    await db.monitoring.update_one(
                                        {"_id": item["_id"]},
                                        {"$set": {"credential_leaks": current_count}}
                                    )
                        except Exception as e:
                            logger.warning("Credential check error for %s: %s", domain, e)
        except Exception as e:
            logger.warning("Credential sensor error: %s", e)
        await asyncio.sleep(7 * 24 * 3600)

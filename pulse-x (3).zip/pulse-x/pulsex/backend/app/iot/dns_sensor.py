import asyncio, logging
import dns.resolver
from app.services.websocket_manager import ws_manager
from app.database import get_db

logger = logging.getLogger(__name__)

async def run_dns_sensor():
    while True:
        try:
            db = get_db()
            if db:
                monitored = await db.monitoring.find({}).to_list(100)
                for item in monitored:
                    domain = item.get("domain")
                    startup_id = str(item.get("_id", item.get("startup_id", "")))
                    prev_ips = set(item.get("dns_ips", []))
                    if domain:
                        try:
                            resolver = dns.resolver.Resolver()
                            resolver.timeout = 5
                            answers = resolver.resolve(domain, "A")
                            current_ips = set(r.address for r in answers)
                            if prev_ips and current_ips != prev_ips:
                                await ws_manager.broadcast(startup_id, {
                                    "type": "DNS_ANOMALY",
                                    "severity": "HIGH",
                                    "domain": domain,
                                    "message": f"DNS records changed. New IPs: {list(current_ips)}",
                                    "previous_ips": list(prev_ips),
                                    "current_ips": list(current_ips),
                                })
                            await db.monitoring.update_one(
                                {"_id": item["_id"]},
                                {"$set": {"dns_ips": list(current_ips)}}
                            )
                        except Exception as e:
                            logger.warning("DNS check error for %s: %s", domain, e)
        except Exception as e:
            logger.warning("DNS sensor error: %s", e)
        await asyncio.sleep(4 * 3600)

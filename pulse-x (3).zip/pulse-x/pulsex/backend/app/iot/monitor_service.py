import asyncio, logging
from app.iot.ssl_sensor import run_ssl_sensor
from app.iot.domain_sensor import run_domain_sensor
from app.iot.credential_sensor import run_credential_sensor
from app.iot.dns_sensor import run_dns_sensor
from app.iot.email_sensor import run_email_sensor

logger = logging.getLogger(__name__)

async def start_all_sensors():
    logger.info("Starting all IoT sensors")
    await asyncio.gather(
        run_ssl_sensor(),
        run_domain_sensor(),
        run_credential_sensor(),
        run_dns_sensor(),
        run_email_sensor(),
        return_exceptions=True,
    )

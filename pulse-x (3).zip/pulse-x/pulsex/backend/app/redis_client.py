import logging
import redis.asyncio as aioredis
from app.config import settings

logger = logging.getLogger(__name__)
redis_client = None

async def init_redis():
    global redis_client
    redis_client = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    logger.info("Redis connected")

async def close_redis():
    global redis_client
    if redis_client:
        await redis_client.close()

def get_redis():
    return redis_client
